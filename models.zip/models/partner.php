<?php
/**
* @package Zedek Framework
* @subpackage User Model
* @version 4
* @author defestdude <defestdude@gmail.com> Donald Mkpanam
*/
namespace __zf__;

class Partner extends Zedek{
	public $userrole;

	static function orm(){
		$orm =  new ZORM;
		$orm =  $orm::cxn();
		$orm->pdo->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
		//$orm->pdo->setAttribute(\PDO::ATTR_EMULATE_PREPARES, false);		
		return $orm;
	}

	

	function create(){
		$db = self::orm()->pdo;
		$datetime = date("Y-m-d H:i:s");
			$q = "insert into partners (name, address, contact_person, contact_phone, contact_email, type) 
			values (:name, :address, :contact_person, :contact_phone, :contact_email, :type)";
			$profile = '1';
			try {
				$query = $db->prepare($q);
				$query->bindParam(':name', $_POST["contact_name"]);
				$query->bindParam(':address', $_POST["address"]);
				$query->bindParam(':contact_person', $_POST["contact_person"]);
				$query->bindParam(':contact_phone', $_POST["contact_phone"]);
				$query->bindParam(':contact_email', $_POST["contact_email"]);
				$query->bindParam(':type', $_POST["type"]);
				$query->execute();
			} catch (Exception $e) {
				echo "Cannot create Partner".$e->getMessage();
			}			

	}

	function get_partners($pth) {
		$viewpath = "http://".$pth."/monitoring/partner/view/";
		$db = self::orm()->pdo;
		$q = "select partners.id, partners.name, address, contact_person, contact_phone, contact_email, partner_type.name as type from partners
		join partner_type on partners.type = partner_type.id";		
		try {
			$query = $db->prepare($q);
			$query->execute();
		} catch (Exception $e) {
			echo "Cannot get Partners".$e->getMessage();
		}
		$results =  $query->fetchAll();
		$display = "";
		for($i = 0; $i < sizeof($results); $i++) {
			$display .= "<tr class='odd gradeX'><td></td><td><a href='".$viewpath.$results[$i]["id"]."'>".$results[$i]["name"]."</a></td>
			<td><a href='".$viewpath.$results[$i]["id"]."'>".$results[$i]["type"]."</a></td>
			<td><a href='".$viewpath.$results[$i]["id"]."'>".$results[$i]["contact_person"]."</a>
			</td>
			<td><a href='".$viewpath.$results[$i]["id"]."'>View</a></td></tr>";
		}
		return $display;                                              
	}

	function get_partner_type() {
		$db = self::orm()->pdo;
		$q = "select id, name from partner_type";		
		try {
			$query = $db->prepare($q);
			$query->execute();
		} catch (Exception $e) {
			echo "Cannot get Partner Types".$e->getMessage();
		}
		$results =  $query->fetchAll();
		return $results;                                              
	}

	function get_mda($id) {
		$db = self::orm()->pdo;
		$q = "select id, mda.name, mda.perm_sec from mda where id = :id";		
		try {
			$query = $db->prepare($q);
			$query->bindParam(":id", $id);
			$query->execute();
		} catch (Exception $e) {
			echo "Cannot get MDA".$e->getMessage();
		}
		$results =  $query->fetchObject();
		return $results;                                              
	}

	function get_mda_project_count($id) {
		$db = self::orm()->pdo;
		$q = "select count(id) as count from project where mda = :id";		
		try {
			$query = $db->prepare($q);
			$query->bindParam(":id", $id);
			$query->execute();
		} catch (Exception $e) {
			echo "Cannot get MDA Projects".$e->getMessage();
		}
		$results =  $query->fetchObject()->count;
		return $results;          

	}

	function get_mda_completed_project_count($id) {
		$db = self::orm()->pdo;
		$q = "select count(project_stats.id) as count from project_stats 
		join project on project_stats.project = project.id
		join mda on project.mda = mda.id where mda.id = :id and project_stats.completion_date is not null";		
		try {
			$query = $db->prepare($q);
			$query->bindParam(":id", $id);
			$query->execute();
		} catch (Exception $e) {
			echo "Cannot get MDA Projects".$e->getMessage();
		}
		$results =  $query->fetchObject()->count;
		return $results;          

	}



	function get_service_news() {
		$db = self::orm()->pdo;
		$q = "select id as id, title as name, body as email , newsdate as newsdate from news order by newsdate desc";		
		try {
			$query = $db->prepare($q);
			$query->execute();
		} catch (Exception $e) {
			echo "Cannot get News".$e->getMessage();
		}
		$results =  $query->fetchAll(\PDO::FETCH_ASSOC);
		return $results;                                              
	}

	function delete_mda($id) {
		$db = self::orm()->pdo;
		$q = "delete from mda where id = :id";		
		try {
			$query = $db->prepare($q);
			$query->bindParam(':id', $id);
			$query->execute();
		} catch (Exception $e) {
			echo "Cannot delete MDA".$e->getMessage();
		}
		                                      
	}

	
	static private function sendWelcomeSMS($email){}

	static private function sendWelcomeEmail($mobile){}


}