<?php
/**
* @package Zedek Framework
* @subpackage User Model
* @version 4
* @author defestdude <defestdude@gmail.com> Donald Mkpanam
*/
namespace __zf__;

class Task extends Zedek{
	public $userrole;

	static function orm(){
		$orm =  new ZORM;
		$orm =  $orm::cxn();
		$orm->pdo->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
		//$orm->pdo->setAttribute(\PDO::ATTR_EMULATE_PREPARES, false);		
		return $orm;
	}

	

	function create(){
		$db = self::orm()->pdo;
		$date_assigned = date("Y-m-d H:i:s");
		$due_date = $_POST["due_date"];
		$assigned_by = $_SESSION["userid"];
		if ($due_date == "") {$due_date = NULL; } else { $due_date = date('Y-m-d',strtotime($due_date)); }
			$q = "insert into tasks (title, description, date_assigned, due_date, assigned_by, assigned_to)
			values (:title, :description, :date_assigned, :due_date, :assigned_by, :assigned_to)";
			try {
				$query = $db->prepare($q);
				$query->bindParam(':title', $_POST["title"]);
				$query->bindParam(':description', $_POST["description"]);
				$query->bindParam(':date_assigned', $date_assigned);
				$query->bindParam(':due_date', $due_date);
				$query->bindParam(':assigned_by', $assigned_by);
				$query->bindParam(':assigned_to', $_POST["assigned_to"]);
				$query->execute();
			} catch (Exception $e) {
				echo "Cannot create Task".$e->getMessage();
			}		
			

	}

	function get_tasks() {
		//$viewpath = "http://".$pth."/$monitoring/mda/view/";
		$db = self::orm()->pdo;
		$role = $_SESSION["role"];
		$q = "";
		if ($role == 1) {
			$q = "select tasks.id, title, description, date_assigned, due_date, date_completed, (select name from users where id  = tasks.assigned_to) as assigned_to,
			(select name from users where id = tasks.assigned_by) from tasks order by date_assigned desc";	
		} else {
			$q = "select tasks.id, title, description, date_assigned, due_date, date_completed, (select name from users where id  = tasks.assigned_to) as assigned_to,
			(select name from users where id = tasks.assigned_by) from tasks where assigned_to = :assigned_to order by date_assigned desc";
		}
			
		try {
			$query = $db->prepare($q);
			if ($role != 1) $query->bindParam(':assigned_to', $_SESSION["userid"]);
			$query->execute();
		} catch (Exception $e) {
			echo "Cannot get all Tasks".$e->getMessage();
		}
		$results =  $query->fetchAll();
		$display = "";
		for($i = 0; $i < sizeof($results); $i++) {
			$desc = $results[$i]["description"];
			$desc = substr($desc,0, 50) . "...";
			$date_completed = $results[$i]["date_completed"];
			$border = "";
			if ($date_completed == NULL) {
				$border = "todo-tasklist-item-border-red";
			}
			else {
				$border = "todo-tasklist-item-border-green";
			}
			$display .= "<tr><td></td><td><div class='todo-tasklist-item ".$border."'>
			<div class='todo-tasklist-item-title'><a href='tasks/view/".$results[$i]["id"]."'>".$results[$i]["title"]."</a></div>
			<div class='todo-tasklist-item-text'> ".$desc."</div>
			<div class='todo-tasklist-controls pull-left'><span class='todo-tasklist-date'>
			<i class='fa fa-calendar'></i>Due Date: ".$results[$i]["due_date"]." | <i class='fa fa-calendar'></i>Date Assigned: ".$results[$i]["date_assigned"]."</span>
			<span class='todo-tasklist-badge badge badge-roundless'>".$results[$i]["assigned_to"]."</span>
			</div></div></td></tr>";
		}
		return $display;                                              
	}

	function get_task($task) {
		$db = self::orm()->pdo;
		$q = "select title, description, date_assigned, due_date, date_completed, (select name from users where id  = tasks.assigned_to) as assigned_to,
			(select name from users where id = tasks.assigned_by) from tasks where tasks.id = :task order by date_assigned desc";
		try {
			$query = $db->prepare($q);
			$query->bindParam(':task', $task);
			$query->execute();
		} catch (Exception $e) {
			echo "Cannot get all Tasks".$e->getMessage();
		}
		$result = $query->fetchObject();
		return $result;
	}

	function add_file($id) {
		$size= $_FILES["task_file"]["size"];
		$date_uploaded = date('Y-m-d H:i:s');
		$ext = pathinfo($_FILES["task_file"]["name"], PATHINFO_EXTENSION);
		$target_dir = "/var/www/html/monitoringbck/bin/documents/";
		$filename1 = basename($_FILES["task_file"]["name"]);
		$user = new User;
		$uploaded_by = $_SESSION["userid"];
		$db = self::orm()->pdo;
		$q = "insert into tasks_files (task, file_name, file_type, uploaded_by, file_size, date_uploaded)
		values (:task, :file_name, :file_type, :uploaded_by, :file_size, :date_uploaded)";		
		try {
			$query = $db->prepare($q);
			$query->bindParam(":task", $id);
			$query->bindParam(":file_name", $filename1);
			$query->bindParam(":file_type", $ext);
			$query->bindParam(":uploaded_by", $uploaded_by);
			$query->bindParam(":file_size", $size);
			$query->bindParam(":date_uploaded", $date_uploaded);
			$query->execute();
		} catch (Exception $e) {
			echo "Cannot get MDAs".$e->getMessage();
		}
		$taskid = $db->lastInsertID();
		$filename = $target_dir .$taskid.".".$ext;
		move_uploaded_file($_FILES["task_file"]["tmp_name"], $filename);
		//return $results;                                              
	}

	function get_files($task) {
		$db = self::orm()->pdo;
		$q = "select file_name, file_type, name as uploaded_by, date_uploaded from 
		tasks_files join users on users.id = tasks_files.uploaded_by where task = :task";		
		try {
			$query = $db->prepare($q);
			$query->bindParam(":task", $task);
			$query->execute();
		} catch (Exception $e) {
			echo "Cannot get Task Files".$e->getMessage();
		}
		$results =  $query->fetchAll();
		$display = "";
		for($i = 0; $i < sizeof($results); $i++) {
			$display .= "<tr> <td> <a href='javascript:;'>".$results[$i]["file_name"]."</a></td>
			<td class='hidden-xs'>".$results[$i]["uploaded_by"]."</td>
<td>".$results[$i]["date_uploaded"]."</td>
<td> <a class='btn btn-sm grey-salsa btn-outline' href='javascript:;'> View </a> </td></tr>";
		}
		return $display;
	}

	function update($id) {
		$db = self::orm()->pdo;
		$title = $_POST["title"];
		$description = $_POST["description"];
		$status = $_POST["status"];
		$date_completed = date('Y-m-d H:i:s');
		$due_date = $_POST["due_date"];
		$due_date = date('Y-m-d',strtotime($due_date));
		$nullref = NULL;
		//echo $due_date;
		$q = "update tasks set title = :title, description = :description, due_date = :due_date, date_completed = :date_completed where id = :id";
		try {
			$query = $db->prepare($q);
			$query->bindParam(":title", $title);
			$query->bindParam(":id", $id);
			$query->bindParam(":description", $description);
			$query->bindParam(":due_date", $due_date);
			if ($status == "2") {
				$query->bindParam(":date_completed", $date_completed);
			} else {
				$query->bindParam(":date_completed", $nullref);
			}
			$query->execute();
		} catch (Exception $e) {
			echo "Cannot Update Task".$e->getMessage();
		}
		//$results =  $query->fetchObject();
		//return $results;                                              
	}

	function get_mda_project_count($id) {
		$db = self::orm()->pdo;
		$q = "select count(id) as count from project where mda = :id";		
		try {
			$query = $db->prepare($q);
			$query->bindParam(":id", $id);
			$query->execute();
		} catch (Exception $e) {
			echo "Cannot get MDA Projects".$e->getMessage();
		}
		$results =  $query->fetchObject()->count;
		return $results;          

	}

	function get_mda_completed_project_count($id) {
		$db = self::orm()->pdo;
		$q = "select count(project_stats.id) as count from project_stats 
		join project on project_stats.project = project.id
		join mda on project.mda = mda.id where mda.id = :id and project_stats.completion_date is not null";		
		try {
			$query = $db->prepare($q);
			$query->bindParam(":id", $id);
			$query->execute();
		} catch (Exception $e) {
			echo "Cannot get MDA Projects".$e->getMessage();
		}
		$results =  $query->fetchObject()->count;
		return $results;          

	}



	function get_service_news() {
		$db = self::orm()->pdo;
		$q = "select id as id, title as name, body as email , newsdate as newsdate from news order by newsdate desc";		
		try {
			$query = $db->prepare($q);
			$query->execute();
		} catch (Exception $e) {
			echo "Cannot get News".$e->getMessage();
		}
		$results =  $query->fetchAll(\PDO::FETCH_ASSOC);
		return $results;                                              
	}

	function delete_mda($id) {
		$db = self::orm()->pdo;
		$q = "delete from mda where id = :id";		
		try {
			$query = $db->prepare($q);
			$query->bindParam(':id', $id);
			$query->execute();
		} catch (Exception $e) {
			echo "Cannot delete MDA".$e->getMessage();
		}
		                                      
	}

	
	static private function sendWelcomeSMS($email){}

	static private function sendWelcomeEmail($mobile){}


}