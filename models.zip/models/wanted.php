<?php
/**
* @package Zedek Framework
* @subpackage User Model
* @version 4
* @author defestdude <defestdude@gmail.com> Donald Mkpanam
*/
namespace __zf__;

class Wanted extends Zedek{
	public $userrole;

	static function orm(){
		$orm =  new ZORM;
		$orm =  $orm::cxn();
		$orm->pdo->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
		//$orm->pdo->setAttribute(\PDO::ATTR_EMULATE_PREPARES, false);		
		return $orm;
	}

	

	function create(){
		$db = self::orm()->pdo;
		$dateofreport = date("Y-m-d H:i:s");
		$q = "insert into wanted_list (name, description, reason, dateofreport, reward, filetype) values (:name, :description, :reason, :dateofreport, :reward, :filetype)";
		$profile = '1';
		try {
			$file_ext = "";
			if (isset($_FILES)) {
				$fname = basename($_FILES["image"]['name']);
				$file_p  = explode('.', $fname);
				$file_ext  = end($file_p);
			}		
			$query = $db->prepare($q);
			$query->bindParam(':name', $_POST["name"]);
			$query->bindParam(':description', $_POST["description"]);
			$query->bindParam(':reason', $_POST["reason"]);
			$query->bindParam(':dateofreport', $dateofreport);
			$query->bindParam(':reward', $_POST["reward"]);
			if (isset($_FILES))
				$query->bindParam(':filetype', $file_ext);
			$query->execute();
			$wanted_id = $db->lastInsertId();
			$im_path = "/var/www/html/kaduna/themes/bauer/wanted/";
			if (isset($_FILES)) move_uploaded_file($_FILES['image']['tmp_name'], $im_path.$wanted_id.".".$file_ext);
		} catch (Exception $e) {
			echo "Cannot create wanted person".$e->getMessage();
		}			

	}

	function get_wanted() {
		$db = self::orm()->pdo;
		$q = "select id, name, description, reason, dateofreport from wanted_list order by dateofreport desc";		
		try {
			$query = $db->prepare($q);
			$query->execute();
		} catch (Exception $e) {
			echo "Cannot get News".$e->getMessage();
		}
		$results =  $query->fetchAll();
		$display = "";
		for($i = 0; $i < sizeof($results); $i++) {
			$display .= "<tr class='odd gradeX'><td><label class='mt-checkbox mt-checkbox-single mt-checkbox-outline'>
			<input type='checkbox' class='checkboxes' value='1' /><span></span></label></td><td>".$results[$i]["name"]."</td><td>".$results[$i]["reason"]."</td>
			<td>".$results[$i]["dateofreport"]."</td><td>
			<span class='label label-sm label-success'><a class='ajax-demo' data-url='http://54.244.106.34/kaduna/wanted/view/".$results[$i]["id"].
			"' data-toggle='modal'> View </a>| <a href='http://54.244.106.34/kaduna/wanted/delete/".$results[$i]["id"]."'>Delete</a> </span></td></tr>";
		}
		return $display;                                              
	}

	function get_item($id) {
		$db = self::orm()->pdo;
		$q = "select id, name, description, reason, reward, dateofreport, filetype from wanted_list where id = :id";		
		try {
			$query = $db->prepare($q);
			$query->bindParam(":id", $id);
			$query->execute();
		} catch (Exception $e) {
			echo "Cannot get News".$e->getMessage();
		}
		$results =  $query->fetchObject();
		return $results;                                              
	}


	function get_service_wanted() {
		$db = self::orm()->pdo;
		$q = "select id as id, name as name, description as description , reason as reason, reward, dateofreport, filetype from wanted_list order by dateofreport desc";		
		try {
			$query = $db->prepare($q);
			$query->execute();
		} catch (Exception $e) {
			echo "Cannot get News".$e->getMessage();
		}
		$results =  $query->fetchAll(\PDO::FETCH_ASSOC);
		return $results;                                              
	}


	function get_type($id) {
		$db = self::orm()->pdo;
		$q = "select filetype from wanted_list where id = :id";		
		try {
			$query = $db->prepare($q);
			$query->bindParam(":id", $id);
			$query->execute();
		} catch (Exception $e) {
			echo "Cannot get News".$e->getMessage();
		}
		$results =  $query->fetchObject();
		return $results->filetype;                                              
	}

	function get_service_news() {
		$db = self::orm()->pdo;
		$q = "select id as id, title as name, body as email , newsdate as newsdate from news order by newsdate desc";		
		try {
			$query = $db->prepare($q);
			$query->execute();
		} catch (Exception $e) {
			echo "Cannot get News".$e->getMessage();
		}
		$results =  $query->fetchAll(\PDO::FETCH_ASSOC);
		return $results;                                              
	}

	function delete_wanted($id) {
		$db = self::orm()->pdo;
		$q = "delete from wanted_list where id = :id";		
		try {
			$query = $db->prepare($q);
			$query->bindParam(':id', $id);
			$query->execute();
		} catch (Exception $e) {
			echo "Cannot delete wanted".$e->getMessage();
		}

	}

	
	static private function sendWelcomeSMS($email){}

	static private function sendWelcomeEmail($mobile){}


}