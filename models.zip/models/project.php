<?php
/**
* @package Zedek Framework
* @subpackage User Model
* @version 4
* @author defestdude <defestdude@gmail.com> Donald Mkpanam
*/
namespace __zf__;

class Project extends Zedek{
	public $userrole;

	static function orm(){
		$orm =  new ZORM;
		$orm =  $orm::cxn();
		$orm->pdo->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
		//$orm->pdo->setAttribute(\PDO::ATTR_EMULATE_PREPARES, false);		
		return $orm;
	}

	

	function create(){
		$db = self::orm()->pdo;
		$datetime = date("Y-m-d H:i:s");
			$q = "insert into project (name, mda, source_code, budget_provision, priority) values (:name, :mda, :source_code, :budget_provision, :priority)";
			$q2 = "insert into project_stats (project) values (:project)";
			$q3 = "insert into indicators(project) values (:project)";
			$q4 = "insert into project_partners (project, partner) values (:project, :partner)";
			$profile = '1';
			try {
				$db->begintransaction();
				$query = $db->prepare($q);
				$query->bindParam(':name', $_POST["name"]);
				$query->bindParam(':mda', $_POST["mda"]);
				$query->bindParam(':source_code', $_POST["source_code"]);
				$query->bindParam(':priority', $_POST["priority"]);
				$query->bindParam(':budget_provision', $_POST["budget_provision"]);
				$query->execute();
				$projectid = $db->lastInsertID();
				$query2 = $db->prepare($q2);
				$query2->bindParam(':project', $projectid);
				$query2->execute();
				$query3 = $db->prepare($q3);
				$query3->bindParam(':project', $projectid);
				$query3->execute();
				foreach($_POST['partners'] as $selected) {
					$query4 = $db->prepare($q4);
					$query4->bindParam(':project', $projectid);
					$query4->bindParam(':partner', $selected);
					$query4->execute();
				}
				$db->commit();
			} catch (Exception $e) {
				echo "Cannot create Project".$e->getMessage();
				$db->rollback();
			}			

	}

	function get_projects($pth) {
		$viewpath = "http://".$pth."/monitoring/project/view/";
		$db = self::orm()->pdo;
		$q = "select project.id, project.name, project.source_code, mda.name as mda, project.budget_provision, priority from project join mda on project.mda = mda.id";		
		try {
			$query = $db->prepare($q);
			$query->execute();
		} catch (Exception $e) {
			echo "Cannot get MDAs".$e->getMessage();
		}
		$results =  $query->fetchAll();
		$display = "";
		for($i = 0; $i < sizeof($results); $i++) {
			$pri = "font-blue";
			if ($results[$i]["priority"] == "High Priority") {
				$pri = "font-red";
			} else if ($results[$i]["priority"] == "Low Priority") {
				$pri = "font-green";
			} 
			$display .= "<tr class='odd gradeX'><td></td><td><a class='{$pri} sbold' href='".$viewpath.$results[$i]["id"]."'>".$results[$i]["name"]."</a></td><td><a href='".$viewpath.$results[$i]["id"]."'>".$results[$i]["mda"]."</a></td>
			<td><a href='".$viewpath.$results[$i]["id"]."'>".$results[$i]["source_code"]."</a></td><td><a href='".$viewpath.$results[$i]["id"]."'>".$results[$i]["budget_provision"]."</a></td><td><a href='".$viewpath.$results[$i]["id"]."'>View</a></td></tr>";
		}
		return $display;                                              
	}

	function get_project_partners($pth, $project) {
		$viewpath = "http://".$pth."/monitoring/project/view/";
		$db = self::orm()->pdo;
		$q = "select partners.id, partners.name from partners 
		join project_partners on project_partners.partner = partners.id
		join project on project.id = project_partners.project
		where project_partners.project = :project";		
		try {
			$query = $db->prepare($q);
			$query->bindParam(":project", $project);
			$query->execute();
		} catch (Exception $e) {
			echo "Cannot get Project Partners".$e->getMessage();
		}
		$results =  $query->fetchAll();
		return $results;                                              
	}

	function get_project($id) {
		$db = self::orm()->pdo;
		$q = "select project.id, project.name, source_code, budget_provision, mda.name as mda, priority from project
		join mda on project.mda = mda.id where project.id = :id";		
		try {
			$query = $db->prepare($q);
			$query->bindParam(":id", $id);
			$query->execute();
		} catch (Exception $e) {
			echo "Cannot get MDA".$e->getMessage();
		}
		$results =  $query->fetchObject();
		return $results;                                              
	}



	function get_projects_mda($mda, $pth) {
		$viewpath = "http://".$pth."/monitoring/project/view/";
		$db = self::orm()->pdo;
		$q = "select project.id, project.name, project.source_code, mda.name as mda, project.budget_provision from project join mda on project.mda = mda.id
		where project.mda = :mda";		
		try {
			$query = $db->prepare($q);
			$query->bindParam(':mda', $mda);
			$query->execute();
		} catch (Exception $e) {
			echo "Cannot get MDAs".$e->getMessage();
		}
		$results =  $query->fetchAll();
		$display = "";
		for($i = 0; $i < sizeof($results); $i++) {
			$display .= "<tr class='odd gradeX'><td></td><td><a href='".$viewpath.$results[$i]["id"]."'>".$results[$i]["name"]."</a></td>
			<td><a href='".$viewpath.$results[$i]["id"]."'>".$results[$i]["mda"]."</a></td><td><a href='".$viewpath.$results[$i]["id"]."'>".$results[$i]["source_code"]."</a>
			</td><td><a href='".$viewpath.$results[$i]["id"]."'>".$results[$i]["budget_provision"]."</a></td><td><a href='".$viewpath.$results[$i]["id"]."'>View</a></td></tr>";
		}
		return $display;
	}

	function get_project_stats($id){
		$db = self::orm()->pdo;
		$q = "select eoi_date, he_approval_date, advert_date, tendering_date, evaluation_date, due_process_date, award_date, signing_date, start_date, completion_date
		from project_stats
		where project = :id";
		try {
			$query = $db->prepare($q);
			$query->bindParam(':id', $id);
			$query->execute();
		} catch (Exception $e) {
			echo "Cannot get Project Stats".$e->getMessage();
		}	
		$results =  $query->fetchObject();
		return $results;
	}


	function get_project_stats_expected($id){
		$db = self::orm()->pdo;
		$q = "select eoi_date_expected, he_approval_date_expected, advert_date_expected, tendering_date_expected, evaluation_date_expected,
		due_process_date_expected, award_date_expected, signing_date_expected, start_date_expected, completion_date_expected
		from project_stats
		where project = :id";
		try {
			$query = $db->prepare($q);
			$query->bindParam(':id', $id);
			$query->execute();
		} catch (Exception $e) {
			echo "Cannot get Project Stats".$e->getMessage();
		}	
		$results =  $query->fetchObject();
		return $results;
	}

	function get_partners() {
		$db = self::orm()->pdo;
		$q = "select id, name from partners";
		try {
			$query = $db->prepare($q);
			$query->execute();
		} catch (Exception $e) {
			echo "Cannot get Project Partners".$e->getMessage();
		}	
		$results =  $query->fetchAll();
		return $results;

	}

	function get_project_timeline($id){
		$db = self::orm()->pdo;
		$q = "select eoi_date, he_approval_date, advert_date, tendering_date, evaluation_date, due_process_date, award_date, signing_date, start_date, completion_date
		from project_stats
		where project = :id";

		$q2 = "select eoi_date_expected, he_approval_date_expected, advert_date_expected, tendering_date_expected, evaluation_date_expected,
		due_process_date_expected, award_date_expected, signing_date_expected, start_date_expected, completion_date_expected
		from project_stats
		where project = :id";

		try {
			$query = $db->prepare($q);
			$query2 = $db->prepare($q2);
			$query->bindParam(':id', $id);
			$query2->bindParam(':id', $id);
			$query->execute();
			$query2->execute();
		} catch (Exception $e) {
			echo "Cannot get Project Stats".$e->getMessage();
		}	
		$results =  $query->fetchObject();
		$results2 =  $query2->fetchObject();

			$timeline_date = "";
			$timeline = "";
		if ($results2->eoi_date_expected != NULL) {
			if ($results->eoi_date != NULL) {
				$d1 = $results->eoi_date;
				$results->eoi_date = date('d/m/Y', strtotime($results->eoi_date));
				$dx = date('F jS, Y', strtotime($d1));
			} else {
				$dx = "Pending";
			}
			$d1 = $results2->eoi_date_expected;
			$results2->eoi_date_expected = date('d/m/Y', strtotime($results2->eoi_date_expected));
			$dx2 = date('F jS, Y', strtotime($d1));
			$timeline_date .= "<li><a href='#0' data-date='".$results2->eoi_date_expected."' class='border-after-yellow-lemon bg-after-yellow-lemon selected'> </a> </li>";
			$timeline .= " <li class='selected' data-date='".$results2->eoi_date_expected."'> <div class='mt-title'> <h2 class='mt-content-title'>Expression of Interest</h2> </div> <div class='mt-author'>
				<div class='mt-author-name'> <a href='javascript:;' class='font-blue-madison'><strong>Expected</strong>: ".$dx2." <br /> <strong>Actual</strong>: ".$dx."</a> </div> </div></li>";
		} else {
			$timeline_date .= "<li><a href='#0' data-date='01/01/2017' class='border-after-red bg-after-red selected'> </a> </li>";
			$timeline .= " <li class='selected' data-date='01/01/2017'> <div class='mt-title'> <h2 class='mt-content-title'>No Activity on this project</h2> </div> <div class='mt-author'>
				<div class='mt-author-name'> <a href='javascript:;' class='font-blue-madison'>No Activity</a>  </div> </div></li>";
		}

		if ($results2->he_approval_date_expected != NULL) {
			if ($results->he_approval_date != NULL) {
				$d1 = $results->he_approval_date;
				$results->he_approval_date = date('d/m/Y', strtotime($results->he_approval_date));
				$dx = date('F jS, Y', strtotime($d1));
			} else {
				$dx = "Pending";
			}

			$d1 = $results2->he_approval_date_expected;
			$results2->he_approval_date_expected = date('d/m/Y', strtotime($results2->he_approval_date_expected));
			$dx2 = date('F jS, Y', strtotime($d1));
			$timeline_date .= "<li><a href='#0' data-date='".$results2->he_approval_date_expected."' class='border-after-blue bg-after-blue '> </a> </li>";
			$timeline .= " <li data-date='".$results2->he_approval_date_expected."'> <div class='mt-title'> <h2 class='mt-content-title'>His Excellency's Approval</h2> </div> <div class='mt-author'>
				<div class='mt-author-name'> <a href='javascript:;' class='font-blue-madison'><strong>Expected</strong>: ".$dx2." <br /> <strong>Actual</strong>: ".$dx."</a>  </div> </div></li>";
		}

		if ($results2->advert_date_expected != NULL) {
			if ($results->advert_date != NULL) {
				$d1 = $results->advert_date;
				$results->advert_date = date('d/m/Y', strtotime($results->advert_date));
				$dx = date('F jS, Y', strtotime($d1));
			} else {
				$dx = "Pending";
			}
			$d1 = $results2->advert_date_expected;
			$results2->advert_date_expected = date('d/m/Y', strtotime($results2->advert_date_expected));
			$dx2 = date('F jS, Y', strtotime($d1));
			$timeline_date .= "<li><a href='#0' data-date='".$results2->advert_date_expected."' class='border-after-green bg-after-green '> </a> </li>";
			$timeline .= " <li data-date='".$results2->advert_date_expected."'> <div class='mt-title'> <h2 class='mt-content-title'>Advert</h2> </div> <div class='mt-author'>
				<div class='mt-author-name'> <a href='javascript:;' class='font-blue-madison'><strong>Expected</strong>: ".$dx2." <br /> <strong>Actual</strong>: ".$dx."</a>  </div> </div></li>";
		}

		if ($results2->tendering_date_expected != NULL) {
			if ($results->tendering_date != NULL) {
				$d1 = $results->tendering_date;
				$results->tendering_date = date('d/m/Y', strtotime($results->tendering_date));
				$dx = date('F jS, Y', strtotime($d1));
			} else {
				$dx = "Pending";
			}
			$d1 = $results2->tendering_date_expected;
			$results2->tendering_date_expected = date('d/m/Y', strtotime($results2->tendering_date_expected));
			$dx2 = date('F jS, Y', strtotime($d1));
			$timeline_date .= "<li><a href='#0' data-date='".$results2->tendering_date_expected."' class='border-after-purple-plum bg-after-purple-plum '> </a> </li>";
			$timeline .= " <li data-date='".$results2->tendering_date_expected."'> <div class='mt-title'> <h2 class='mt-content-title'>Tendering Period</h2> </div> <div class='mt-author'>
				<div class='mt-author-name'> <a href='javascript:;' class='font-blue-madison'><strong>Expected</strong>: ".$dx2." <br /> <strong>Actual</strong>: ".$dx."</a>  </div> </div></li>";
		}

		if ($results2->evaluation_date_expected != NULL) {
			if ($results->evaluation_date != NULL) {
				$d1 = $results->evaluation_date;
				$results->evaluation_date = date('d/m/Y', strtotime($results->evaluation_date));
				$dx = date('F jS, Y', strtotime($d1));
			} else {
				$dx = "Pending";
			}
			$d1 = $results2->evaluation_date_expected;
			$results2->evaluation_date_expected = date('d/m/Y', strtotime($results2->evaluation_date_expected));
			$dx2 = date('F jS, Y', strtotime($d1));
			$timeline_date .= "<li><a href='#0' data-date='".$results2->evaluation_date_expected."' class='border-after-blue bg-after-blue '> </a> </li>";
			$timeline .= " <li data-date='".$results2->evaluation_date_expected."'> <div class='mt-title'> <h2 class='mt-content-title'>Evaluation Date</h2> </div> <div class='mt-author'>
				<div class='mt-author-name'> <a href='javascript:;' class='font-blue-madison'><strong>Expected</strong>: ".$dx2." <br /> <strong>Actual</strong>: ".$dx."</a>  </div> </div></li>";
		}

		if ($results2->due_process_date_expected != NULL) {
			if ($results->due_process_date != NULL) {
				$d1 = $results->due_process_date;
				$results->due_process_date = date('d/m/Y', strtotime($results->due_process_date));
				$dx = date('F jS, Y', strtotime($d1));
			} else {
				$dx = "Pending";
			}
			$d1 = $results2->due_process_date_expected;
			$results2->due_process_date_expected = date('d/m/Y', strtotime($results2->due_process_date_expected));
			$dx2 = date('F jS, Y', strtotime($d1));
			$timeline_date .= "<li><a href='#0' data-date='".$results2->due_process_date_expected."' class='border-after-green bg-after-green '> </a> </li>";
			$timeline .= " <li data-date='".$results2->due_process_date_expected."'> <div class='mt-title'> <h2 class='mt-content-title'>Due Process Date</h2> </div> <div class='mt-author'>
				<div class='mt-author-name'> <a href='javascript:;' class='font-blue-madison'><strong>Expected</strong>: ".$dx2." <br /> <strong>Actual</strong>: ".$dx."</a>  </div> </div></li>";
		}

		if ($results2->award_date_expected != NULL) {
			if ($results->award_date != NULL) {
				$d1 = $results->award_date;
				$results->award_date = date('d/m/Y', strtotime($results->award_date));
				$dx = date('F jS, Y', strtotime($d1));
			} else {
				$dx = "Pending";
			}
			$d1 = $results2->award_date_expected;
			$results2->award_date_expected = date('d/m/Y', strtotime($results2->award_date_expected));
			$dx2 = date('F jS, Y', strtotime($d1));
			$timeline_date .= "<li><a href='#0' data-date='".$results2->award_date_expected."' class='border-after-red bg-after-red '> </a> </li>";
			$timeline .= " <li data-date='".$results2->award_date_expected."'> <div class='mt-title'> <h2 class='mt-content-title'>Contract Award Date</h2> </div> <div class='mt-author'>
				<div class='mt-author-name'> <a href='javascript:;' class='font-blue-madison'><strong>Expected</strong>: ".$dx2." <br /> <strong>Actual</strong>: ".$dx."</a>  </div> </div></li>";
		}

		if ($results2->signing_date_expected != NULL) {
			if ($results->signing_date != NULL) {
				$d1 = $results->signing_date;
				$results->signing_date = date('d/m/Y', strtotime($results->signing_date));
				$dx = date('F jS, Y', strtotime($d1));
			} else {
				$dx = "Pending";
			}
			$d1 = $results2->signing_date_expected;
			$results2->signing_date_expected = date('d/m/Y', strtotime($results2->signing_date_expected));
			$dx2 = date('F jS, Y', strtotime($d1));
			$timeline_date .= "<li><a href='#0' data-date='".$results2->signing_date_expected."' class='border-after-blue bg-after-blue '> </a> </li>";
			$timeline .= " <li data-date='".$results2->signing_date_expected."'> <div class='mt-title'> <h2 class='mt-content-title'>Contract Signing Date</h2> </div> <div class='mt-author'>
				<div class='mt-author-name'> <a href='javascript:;' class='font-blue-madison'><strong>Expected</strong>: ".$dx2." <br /> <strong>Actual</strong>: ".$dx."</a>  </div> </div></li>";
		}

		if ($results2->start_date_expected != NULL) {
			if ($results->start_date != NULL) {
				$d1 = $results->start_date;
				$results->start_date = date('d/m/Y', strtotime($results->start_date));
				$dx = date('F jS, Y', strtotime($d1));
			} else {
				$dx = "Pending";
			}
			$d1 = $results2->start_date_expected;
			$results2->start_date_expected = date('d/m/Y', strtotime($results2->start_date_expected));
			$dx2 = date('F jS, Y', strtotime($d1));
			$timeline_date .= "<li><a href='#0' data-date='".$results2->start_date_expected."' class='border-after-green-soft bg-after-green-soft '> </a> </li>";
			$timeline .= " <li data-date='".$results2->start_date_expected."'> <div class='mt-title'> <h2 class='mt-content-title'>Start Date</h2> </div> <div class='mt-author'>
				<div class='mt-author-name'> <a href='javascript:;' class='font-blue-madison'><strong>Expected</strong>: ".$dx2." <br /> <strong>Actual</strong>: ".$dx."</a>  </div> </div></li>";
		}

		if ($results2->completion_date_expected != NULL) {
			if ($results->completion_date != NULL) {
				$d1 = $results->completion_date;
				$results->completion_date = date('d/m/Y', strtotime($results->completion_date));
				$dx = date('F jS, Y', strtotime($d1));
			} else {
				$dx = "Pending";
			}
			$d1 = $results2->completion_date_expected;
			$results2->completion_date_expected = date('d/m/Y', strtotime($results2->completion_date_expected));
			$dx2 = date('F jS, Y', strtotime($d1));
			$timeline_date .= "<li><a href='#0' data-date='".$results2->completion_date_expected."' class='border-after-green-jungle bg-after-green-jungle '> </a> </li>";
			$timeline .= " <li data-date='".$results2->completion_date_expected."'> <div class='mt-title'> <h2 class='mt-content-title'>Completion Date</h2> </div> <div class='mt-author'>
				<div class='mt-author-name'> <a href='javascript:;' class='font-blue-madison'><strong>Expected</strong>: ".$dx2." <br /> <strong>Actual</strong>: ".$dx."</a>  </div> </div></li>";
		}



		$final = array();
		$final[0] = $timeline_date;
		$final[1] = $timeline;
		return $final;

	}

	function update_project_stats($id) {
		$db = self::orm()->pdo;
		$eoi_date = $_POST["eoi_date"];
		if ($eoi_date == "") { $eoi_date = NULL; } else { $eoi_date = date('Y-m-d',strtotime($eoi_date)); }
		$he_approval_date = $_POST["he_approval_date"];
		if ($he_approval_date == "") {$he_approval_date = NULL; } else { $he_approval_date = date('Y-m-d',strtotime($he_approval_date)); }
		$advert_date = $_POST["advert_date"];
		if ($advert_date == "") { $advert_date = NULL; } else { $advert_date = date('Y-m-d',strtotime($advert_date)); }
		$tendering_date = $_POST["tendering_date"];
		if ($tendering_date == "") { $tendering_date = NULL; } else { $tendering_date = date('Y-m-d',strtotime($tendering_date)); }
		$evaluation_date = $_POST["evaluation_date"];
		if ($evaluation_date == "") { $evaluation_date = NULL; } else { $evaluation_date = date('Y-m-d',strtotime($evaluation_date)); }
		$due_process_date = $_POST["due_process_date"];
		if ($due_process_date == "") { $due_process_date = NULL; } else { $due_process_date = date('Y-m-d',strtotime($due_process_date)); }
		$award_date = $_POST["award_date"];
		if ($award_date == "") { $award_date = NULL; } else { $award_date = date('Y-m-d',strtotime($award_date)); }
		$signing_date = $_POST["signing_date"];
		if ($signing_date == "") { $signing_date = NULL; } else { $signing_date = date('Y-m-d',strtotime($signing_date)); }
		$start_date = $_POST["start_date"];
		if ($start_date == "") { $start_date = NULL; } else { $start_date = date('Y-m-d',strtotime($start_date)); }
		$completion_date = $_POST["completion_date"];
		if ($completion_date == "") { $completion_date = NULL; } else { $completion_date = date('Y-m-d',strtotime($completion_date)); }
		$q = "update project_stats set
		eoi_date = :eoi_date,
		he_approval_date = :he_approval_date,
		advert_date = :advert_date,
		tendering_date = :tendering_date,
		evaluation_date = :evaluation_date,
		due_process_date = :due_process_date,
		award_date = :award_date,
		signing_date = :signing_date,
		start_date = :start_date,
		completion_date = :completion_date
		where project = :id";	
		try {
			$query = $db->prepare($q);
			$query->bindParam(':eoi_date', $eoi_date);
			$query->bindParam(':he_approval_date', $he_approval_date);
			$query->bindParam(':advert_date', $advert_date);
			$query->bindParam(':tendering_date', $tendering_date);
			$query->bindParam(':evaluation_date', $evaluation_date);
			$query->bindParam(':due_process_date', $due_process_date);
			$query->bindParam(':award_date', $award_date);
			$query->bindParam(':signing_date', $signing_date);
			$query->bindParam(':start_date', $start_date);
			$query->bindParam(':completion_date', $completion_date);
			$query->bindParam(':id', $id);
			$query->execute();
		} catch (Exception $e) {
			echo "Cannot update Project Stats".$e->getMessage();
		}
	}

	function update_project_indicators($id){
		$db = self::orm()->pdo;
		$q = "update indicators set
		stability = :stability,
		technical_involvement = :technical_involvement,
		legal = :legal,
		socio_economic = :socio_economic,
		financial = :financial,
		stakeholder = :stakeholder,
		completion_date = :completion_date,
		geographic = :geographic,
		weighted = :weighted
		where project = :project";	
		try {

			$query = $db->prepare($q);
			$query->bindParam(':stability', $_POST["stability"]);
			$query->bindParam(':technical_involvement', $_POST["technical_involvement"]);
			$query->bindParam(':legal', $_POST["legal"]);
			$query->bindParam(':socio_economic', $_POST["socio-economic"]);
			$query->bindParam(':financial', $_POST["financial"]);
			$query->bindParam(':stakeholder', $_POST["stakeholder"]);
			$query->bindParam(':completion_date', $_POST["completion_date_indicator"]);
			$query->bindParam(':geographic', $_POST["geographic"]);
			$query->bindParam(':weighted', $_POST["weighted"]);
			$query->bindParam(':project', $id);
			$query->execute();
		} catch (Exception $e) {
			echo "Cannot update Project Indicators".$e->getMessage();
		}
	}

	function get_project_indicators($id) {
		$db = self::orm()->pdo;
		$q = "select stability, technical_involvement, legal, socio_economic, financial, stakeholder, completion_date, geographic,
		weighted from indicators where project = :project";
		try {
			$query = $db->prepare($q);
			$query->bindParam(':project', $id);
			$query->execute();
		} catch (Exception $e) {
			echo "Cannot getProject Indicators".$e->getMessage();
		}
		$result = $query->fetchObject();
		return $result;
	}

	function add_payment($id) {
		$db = self::orm()->pdo;
		$q = "insert into project_payments(project, amount, date_paid, funding_source) values (:project, :amount, :date_paid, :funding_source)";
		$project = $id;
		$amount = $_POST["amount"];
		$date_paid = $_POST["date_paid"];
		$date_paid = date('Y-m-d',strtotime($date_paid));
		try {
			$query = $db->prepare($q);
			$query->bindParam(':project', $project);
			$query->bindParam(':amount', $amount);
			$query->bindParam(':date_paid', $date_paid);
			$query->bindParam(':funding_source', $_POST["funding_source"]);

			$query->execute();
		} catch (Exception $e) {
			echo "Cannot add payment details".$e->getMessage();
		}
	}

	function get_payments($id) {
		$db = self::orm()->pdo;
		$q = "select amount, date_paid, partners.name as funding_source from project_payments
		join partners on project_payments.funding_source = partners.id
		where project_payments.project = :project";
		$project = $id;
		try {
			$query = $db->prepare($q);
			$query->bindParam(':project', $project);
			$query->execute();
		} catch (Exception $e) {
			echo "Cannot get payment details".$e->getMessage();
		}
		$results =  $query->fetchAll();
		$display = "";
		for($i = 0; $i < sizeof($results); $i++) {
			$date_paid = strtotime($results[$i]["date_paid"]);
			$date_paid = date('F jS, Y', $date_paid);
			$display .= "<li class='mt-list-item'><div class='list-icon-container done'><i class='icon-check'></i>
		</div><div class='list-item-content'><h3>
		<a href='javascript:;'>N".$results[$i]["amount"]." - ".$date_paid.", <strong>Source: </strong>".$results[$i]["funding_source"]."</a></h3></div></li>";
		}
		return $display;  

	}


	function get_total_payments($id) {
		$db = self::orm()->pdo;
		$q = "select sum(amount) as amount from project_payments where project = :project";
		$project = $id;
		try {
			$query = $db->prepare($q);
			$query->bindParam(':project', $project);
			$query->execute();
		} catch (Exception $e) {
			echo "Cannot get payment details".$e->getMessage();
		}
		$result =  $query->fetchObject()->amount;
		if ($result == NULL) {
			$result = "0.00";
		}
		return $result;  

	}



	//Update projects - Expected
	function update_project_stats_expected($id) {
		$db = self::orm()->pdo;
		$eoi_date = $_POST["eoi_date_expected"];
		if ($eoi_date == "") { $eoi_date = NULL; } else { $eoi_date = date('Y-m-d',strtotime($eoi_date)); }
		$he_approval_date = $_POST["he_approval_date_expected"];
		if ($he_approval_date == "") {$he_approval_date = NULL; } else { $he_approval_date = date('Y-m-d',strtotime($he_approval_date)); }
		$advert_date = $_POST["advert_date_expected"];
		if ($advert_date == "") { $advert_date = NULL; } else { $advert_date = date('Y-m-d',strtotime($advert_date)); }
		$tendering_date = $_POST["tendering_date_expected"];
		if ($tendering_date == "") { $tendering_date = NULL; } else { $tendering_date = date('Y-m-d',strtotime($tendering_date)); }
		$evaluation_date = $_POST["evaluation_date_expected"];
		if ($evaluation_date == "") { $evaluation_date = NULL; } else { $evaluation_date = date('Y-m-d',strtotime($evaluation_date)); }
		$due_process_date = $_POST["due_process_date_expected"];
		if ($due_process_date == "") { $due_process_date = NULL; } else { $due_process_date = date('Y-m-d',strtotime($due_process_date)); }
		$award_date = $_POST["award_date_expected"];
		if ($award_date == "") { $award_date = NULL; } else { $award_date = date('Y-m-d',strtotime($award_date)); }
		$signing_date = $_POST["signing_date_expected"];
		if ($signing_date == "") { $signing_date = NULL; } else { $signing_date = date('Y-m-d',strtotime($signing_date)); }
		$start_date = $_POST["start_date_expected"];
		if ($start_date == "") { $start_date = NULL; } else { $start_date = date('Y-m-d',strtotime($start_date)); }
		$completion_date = $_POST["completion_date_expected"];
		if ($completion_date == "") { $completion_date = NULL; } else { $completion_date = date('Y-m-d',strtotime($completion_date)); }
		$q = "update project_stats set
		eoi_date_expected = :eoi_date,
		he_approval_date_expected = :he_approval_date,
		advert_date_expected = :advert_date,
		tendering_date_expected = :tendering_date,
		evaluation_date_expected = :evaluation_date,
		due_process_date_expected = :due_process_date,
		award_date_expected = :award_date,
		signing_date_expected = :signing_date,
		start_date_expected = :start_date,
		completion_date_expected = :completion_date
		where project = :id";	
		try {
			$query = $db->prepare($q);
			$query->bindParam(':eoi_date', $eoi_date);
			$query->bindParam(':he_approval_date', $he_approval_date);
			$query->bindParam(':advert_date', $advert_date);
			$query->bindParam(':tendering_date', $tendering_date);
			$query->bindParam(':evaluation_date', $evaluation_date);
			$query->bindParam(':due_process_date', $due_process_date);
			$query->bindParam(':award_date', $award_date);
			$query->bindParam(':signing_date', $signing_date);
			$query->bindParam(':start_date', $start_date);
			$query->bindParam(':completion_date', $completion_date);
			$query->bindParam(':id', $id);
			$query->execute();
		} catch (Exception $e) {
			echo "Cannot update Project Stats".$e->getMessage();
		}
	}

	

	
	static private function sendWelcomeSMS($email){}

	static private function sendWelcomeEmail($mobile){}


}