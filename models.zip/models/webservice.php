<?php

namespace __zf__;

class PayDirect extends ZModel{

	private $authorized_ips = array();

	function __construct(){
		parent::__construct();
	}

	function authorizeIP($ip){
		if(empty($ip)){
			return true;
		}
		array_push($this->authorized_ips, $ip);
	}

	function authorizedIPs($ip){
		if(in_array($ip, $this->authorized_ips)){
			return true;
		} else {
			//exit;
			//return false;
			return true;
		}
	}

	function sos($xml){
		$db = self::orm()->pdo;

		
		header("Content-type: text/xml");
		print $response;
		return $response_status;
	}

	function paymentNotification($xml, $ip){

		$request = simplexml_load_string($xml);
		$response_status = 0;
		$dbo = $this->orm->dbo;

		try{
			$dbo->beginTransaction();
			if($this->orm->table("accounts")->exists((string)$request->Payments->Payment->CustReference, "AccountNo") && $this->authorizedIPs($ip)){
				$record = array(
					"PaymentRef"=> (string)$request->Payments->Payment->PaymentReference,
					"PaymentDate"=> strftime("%Y-%m-%d %H:%M:%S", strtotime($request->Payments->Payment->PaymentDate)),
					"AccountNo"=> (string)$request->Payments->Payment->CustReference,
					"ReceiptNo"=> (string)$request->Payments->Payment->ReceiptNo,
					"CustomerName"=> (string)$request->Payments->Payment->CustomerName,
					"PaymentDescription"=> (string)$request->Payments->Payment->PaymentItems->PaymentItem->ItemName,
					"Amount"=> (string)((float)$request->Payments->Payment->Amount),
					"PaymentMethod"=>(string)$request->Payments->Payment->PaymentMethod, 
					"DepositSlip"=> (string)$request->Payments->Payment->DepositSlipNumber,
					"ChequeDate"=> strftime("%Y-%m-%d %H:%M:%S", strtotime($request->Payments->Payment->SettlementDate)),
					"Bank"=> (string)$request->Payments->Payment->BankName,
					"AdditionalInfo"=> $request->Payments->Payment->Amount >= 0 ? "Payment" : "Reversal",
					"BankBranch"=> (string)$request->Payments->Payment->Location,
					"PaymentCode"=> (string)$request->Payments->Payment->PaymentItems->PaymentItem->ItemCode,
					"Processed"=> "0"
				);

				$sql = "	INSERT INTO payments (
								PaymentRef,
								PaymentDate,
								AccountNo,
								ReceiptNo,
								CustomerName,
								PaymentDescription,
								Amount,
								PaymentMethod, 
								DepositSlip,
								ChequeDate,
								Bank,
								AdditionalInfo,
								BankBranch,
								PaymentCode,
								Processed	
							) VALUES (
								?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? 						
							)
				";

				/*updating accounts table*/
				if($this->orm->table("payments")->exists((string)$request->Payments->Payment->PaymentReference, "PaymentRef")) {
				} else {
					$acct = new accounts;
					if($record["AdditionalInfo"] == "Payment"){
						$acct->credit($record["AccountNo"], $record["Amount"], $record["PaymentDescription"]);
					} else {
						$acct->debit($record["AccountNo"], $record["Amount"], "Reversal");
					}
				
				$stmt = $dbo->prepare($sql);
				$stmt->execute(array_values($record));
				}
				$dbo->commit();							
			} else {
				throw new \Exception("there was a problem");
			}

		} catch(\Exception $e){
			$response_status = 1;
			$dbo->rollback();
		}

		$response = "<?xml version='1.0' encoding='utf-8' ?>
							<PaymentNotificationResponse>
								<Payments>
									<Payment>
										<PaymentLogId>{$payment_log_id}</PaymentLogId>
										<Status>{$response_status}</Status>
									</Payment>
								</Payments>
							</PaymentNotificationResponse>";

		header("Content-type: text/xml");
		print $response;
	}



}


?>