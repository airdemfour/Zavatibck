<?php
/**
* @package Zedek Framework
* @subpackage User Model
* @version 4
* @author defestdude <defestdude@gmail.com> Donald Mkpanam
*/
namespace __zf__;

class User extends Zedek{
	public $userrole;

	static function orm(){
		$orm =  new ZORM;
		$orm =  $orm::cxn();
		$orm->pdo->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
		//$orm->pdo->setAttribute(\PDO::ATTR_EMULATE_PREPARES, false);		
		return $orm;
	}

	public function login() {
		$username = $_POST["username"];
		$password = $_POST["password"];
		$password = md5($password);
		$db = self::orm()->pdo;
		$return = 0;
		$q ="select id from users where email = :username and password = :password";
		try {
			$query = $db->prepare($q);
			$query->bindParam(':username', $username);
			$query->bindParam(':password', $password);
			$query->execute();
		} catch (Exception $e) {
			echo "Cannot Login.".$e->getMessage();
		}
		$res = $query->fetchObject();

		if (is_object($res)) {
			$return = $res->id;
			$_SESSION["username"] = $username;
			$_SESSION["role"] = $this->get_user_role($return);
			//echo $_SESSION["role"];
		}
		return $return;
	}

	private function get_user_role($user) {
		$db = self::orm()->pdo;
		$q ="select role from users_roles where user = :user";
		try {
			$query = $db->prepare($q);
			$query->bindParam(':user', $user);
			$query->execute();
		} catch (Exception $e) {
			echo "Cannot User Role.".$e->getMessage();
		}
		return $query->fetchObject()->role;
	}
	
	public function get_name_from_username($id) {
		$db = self::orm()->pdo;
		$q ="select name from users where id = :id";
		try {
			$query = $db->prepare($q);
			$query->bindParam(':id', $id);
			$query->execute();
		} catch (Exception $e) {
			echo "Cannot Get User Name.".$e->getMessage();
		}
		return $query->fetchObject()->name;
	}

	function create_user(){
		$db = self::orm()->pdo;
		$q1 = "insert into users (name, email, password, datecreated, address, phone) values (:name, :email, :password, :date_created, :address, :phone)";
		$q2 = "insert into users_mdas (user, mda) values (:user, :mda)";
		$q3 = "insert into users_roles (user, role) values (:user, :role)";
		$datecreated = date("Y-m-d H:i:s");

		$name = $_POST["name"];
		$email = $_POST["email"];
		$password = $_POST["password"];
		$password = md5($password);
		$mda = $_POST["mda"];
		$role = $_POST["role"];

		try {
			$db->begintransaction();
			$query = $db->prepare($q1);
			$query->bindParam(':name', $name);
			$query->bindParam(':email', $email);
			$query->bindParam(':password', $password);
			$query->bindParam(':date_created', $datecreated);
			$query->bindParam(':address', $_POST["address"]);
			$query->bindParam(':phone', $_POST["phone"]);
			$query->execute();
			$user = $db->lastInsertID();

			$query2 = $db->prepare($q2);
			$query2->bindParam(':user', $user);
			$query2->bindParam(':mda', $mda);
			$query2->execute();

			$query3 = $db->prepare($q3);
			$query3->bindParam(':user', $user);
			$query3->bindParam(':role', $role);
			$query3->execute();
			$db->commit();

			$ext = pathinfo($_FILES["profile_photo"]["name"], PATHINFO_EXTENSION);
			$target_dir = "/var/www/html/monitoringbck/bin/users/";
			$filename = $target_dir .$user.".".$ext;
			move_uploaded_file($_FILES["profile_photo"]["tmp_name"], $filename);

		} catch (Exception $e) {
			echo "Cannot create user ".$e->getMessage();
			$db->rollback();
		}

	}

	function get_user_types() {
		$db = self::orm()->pdo;
		$q = "select id, name from roles";		
		try {
			$query = $db->prepare($q);
			$query->execute();
		} catch (Exception $e) {
			echo "Cannot get User Types".$e->getMessage();
		}
		$results =  $query->fetchAll();
		return $results;                                              
	}



	function get_users($pth) {
		$viewpath = "http://".$pth."/monitoring/project/view/";
		$db = self::orm()->pdo;
		$q = "select users.id, users.name, email, mda.name as MDA, roles.name as Role from users 
		join users_mdas on users.id = users_mdas.user
		join mda on users_mdas.mda = mda.id
		join users_roles on users.id = users_roles.user
		join roles on users_roles.role = roles.id";		
		try {
			$query = $db->prepare($q);
			$query->execute();
		} catch (Exception $e) {
			echo "Cannot get Users".$e->getMessage();
		}
		$display = "";
		$results =  $query->fetchAll();
		for($i = 0; $i < sizeof($results); $i++) {
			$display .= "<tr class='odd gradeX'><td></td><td><a href='".$viewpath.$results[$i]["id"]."'>".$results[$i]["name"]."</a></td><td><a href='".$viewpath.$results[$i]["id"]."'>".$results[$i]["email"]."</a></td>
			<td><a href='".$viewpath.$results[$i]["id"]."'>".$results[$i]["Role"]."</a></td><td><a href='".$viewpath.$results[$i]["id"]."'>".$results[$i]["MDA"]."</a></td><td><a href='#'>View</a></td></tr>";
		}
		return $display;
	}

	function get_users_list() {
		$db = self::orm()->pdo;
		$q = "select users.id, users.name from users";
		try {
			$query = $db->prepare($q);
			$query->execute();
		} catch (Exception $e) {
			echo "Cannot get Users".$e->getMessage();
		}
		$display = "";
		$results =  $query->fetchAll();
		for($i = 0; $i < sizeof($results); $i++) {
			if ($i == 0) {
				$display .= "<option value='".$results[$i]["id"]."' selected='selected'>".$results[$i]["name"]."</option>";
			} else {
				$display .= "<option value='".$results[$i]["id"]."'>".$results[$i]["name"]."</option>";
			}
			
		}
		return $display;
	}

	function get_user_category($userid) {
		$db = self::orm()->pdo;
		$q = "select role from staff_roles where staff = :id";		
		try {
			$query = $db->prepare($q);
			$query->bindParam(':id', $userid);
			$query->execute();
		} catch (Exception $e) {
			echo "Cannot get archives count".$e->getMessage();
		}
		return $query->fetchObject()->role;
	}

	function get_user_name($userid) {
		$db = self::orm()->pdo;
		$q = "select concat(firstname, ' ',surname) as name from staff where id = :id";		
		try {
			$query = $db->prepare($q);
			$query->bindParam(':id', $userid);
			$query->execute();
		} catch (Exception $e) {
			echo "Cannot get user name".$e->getMessage();
		}
		return $query->fetchObject()->name;
	}



	static private function sendWelcomeSMS($email){}

	static private function sendWelcomeEmail($mobile){}


}