<?php
/**
* @package Zedek Framework
* @subpackage ZConfig zedek configuration class
* @version 4
* @author defestdude <defestdude@gmail.com> Donald Mkpanam
*/

namespace __zf__;
class CController extends ZController{
	public $app;


	function __construct() {
		parent::__construct();
		//$this->model = new user;
		$c = new ZConfig;
		$this->app = new app;
	}

	function index(){
		$tmp = $this->app->tmp();
		$sos = new Sos;
		$soscordinates = $sos->get_sos_cordinates();
		$tmp["page_title"] = "Dasdhboard - Kaduna Eye";
		$tmp["soscordinates"] = $soscordinates;
		self::render("index", $tmp);
		
	}

	public function about(){
		self::render("about");
		
	}

}
