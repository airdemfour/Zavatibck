<?php
/*
for templating
template keys used as variables return array values 
eg  echo $foo;  will return bar 

* Important: comment your javascript and php code in multiline commenting style not with // double slashes or # hashes!
*/



echo "Hello world";

?>