<?php
/**
* @package Zedek Framework
* @subpackage ZConfig zedek configuration class
* @version 4
* @author defestdude <defestdude@gmail.com> Donald Mkpanam
*/

namespace __zf__;
class CController extends ZController{
	public $app;


	function __construct() {
		parent::__construct();
		//$this->model = new user;
		$c = new ZConfig;
		$this->app = new app;
	}

	function index(){
		if(!isset($_SESSION["userid"])) {
			$this->login();
		} else {
			$tmp = $this->app->tmp();		
			$tmp["page_title"] = "Dashboard - Kaduna State Monitoring & Intelligence System";
			self::render($tmp,"index");
		}	
		
		
	}

	public function login(){
		if(isset($_POST["username"])) {
			$user = new User;
			$status = $user->login();
			if ($status != 0) {
				$_SESSION["userid"] = $status;
				//echo $_SESSION["userid"];
				$this->redirect("default", "index");
			} else {
				self::display("login");
			}
		} else {
			self::display("login");
		}

	}

	public function logout() {
		unset($_SESSION["userid"]);
		$this->login();
	}
}
