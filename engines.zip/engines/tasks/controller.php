<?php
/**
* @package Zedek Framework
* @subpackage ZConfig zedek configuration class
* @version 4
* @author defestdude <defestdude@gmail.com> Donald Mkpanam
*/

namespace __zf__;
class CController extends ZController{
	public $app;


	function __construct() {
		parent::__construct();
		//$this->model = new user;
		$c = new ZConfig;
		$this->app = new app;
	}

	function index(){
		$task = new Task;
		$user = new User;
		if(isset($_POST["title"])) {
			$task->create();
		}
		$tasks = $task->get_tasks();
		$users = $user->get_users_list();
		$tmp = $this->app->tmp();
		$tmp["users"] = $users;
		$tmp["tasks"] = $tasks;
		if ($_SESSION["role"] == 1) {
			self::render("index", $tmp);	
		} else {
			self::render("index_user", $tmp);
		}
		
		
	}

	function view(){
		$id = $this->uri->id;
		$tmp = $this->app->tmp();
		$task = new Task;
		if(isset($_POST["fileuploader"])) {
			$task->add_file($id);
		}
		if(isset($_POST["task_edit"])) {
			$task->update($id);
		}
		$taskdetails = $task->get_task($id);
		$duedate2 = date('m/d/Y', strtotime($taskdetails->due_date));
		$tmp["tasktitle"] = $taskdetails->title;
		$tmp["taskdesc"] = $taskdetails->description;
		$tmp["date_assigned"] = $taskdetails->date_assigned;
		$tmp["due_date"] = $taskdetails->due_date;
		$tmp["duedate2"] = $duedate2;
		$date_completed = $taskdetails->date_completed;
		$project_stat = 0;
		$project_stat2= 1;
		if ($date_completed == NULL) {
			$project_stat = "Pending";
			$project_stat2 = "1";
			$date_completed = " ";
		}else {
			$project_stat = "Completed";
			$project_stat2 = "2";
		}
		$tmp["date_completed"] = $date_completed;
		$tmp["project_stat"] = $project_stat;
		$tmp["project_stat2"] = $project_stat2;
		$tmp["task_files"] = $task->get_files($id);
		self::render($tmp, "view");

	}

	

	function delete() {
		$id = $this->uri->id;
		$mda = new Mda;
		$wanted->delete_wanted($id);
		$this->redirect("mda", "index");
	}


}
