<?php
/**
* @package Zedek Framework
* @subpackage ZConfig zedek configuration class
* @version 4
* @author defestdude <defestdude@gmail.com> Donald Mkpanam
*/

namespace __zf__;
class CController extends ZController{
	public $app;


	function __construct() {
		parent::__construct();
		//$this->model = new user;
		$c = new ZConfig;
		$this->app = new app;
	}

	function index(){
		$project = new Project;
		$mda = new Mda;
		if(isset($_POST["name"])) {
			$project->create();
		}
		$mdas = $mda->get_mda_list();
		$projects = $project->get_projects($this->uri->server);
		$tmp = $this->app->tmp();
		$tmp["partners"] = $project->get_partners();
		$tmp["projects"] = $projects;
		$tmp["mdas"] = $mdas;
		self::render("index", $tmp);
		
	}

	function view(){
		$id = $this->uri->id;
		$tmp = $this->app->tmp();
		$project = new Project;
		if(isset($_POST["checker"])) {
			$project->update_project_stats($id);
		}
		if(isset($_POST["checker_expected"])) {
			$project->update_project_stats_expected($id);
		}
		if(isset($_POST["monies"])) {
			$project->add_payment($id);
		}
		if(isset($_POST["indicator"])) {
			$project->update_project_indicators($id);
		}

		$project_details = $project->get_project($id);
		$project_stats = $project->get_project_stats($id);
		$project_stats_expected = $project->get_project_stats_expected($id);
		$timeline = $project->get_project_timeline($id);
		$indicators = $project->get_project_indicators($id);

		$priority_code = "blue";
		$priority = $project_details->priority;
		if ($priority == "High Priority") {
			$priority_code = "red";
		} else if ($priority == "Low Priority") {
			$priority_code = "green";
		}


		$eoi_date = $project_stats->eoi_date;if ($eoi_date == NULL) $eoi_date = "";
		if ($eoi_date != "") $eoi_date = date("m/d/Y", strtotime($eoi_date));
		$he_approval_date = $project_stats->he_approval_date; if ($he_approval_date == NULL) $he_approval_date = "";
		if ($he_approval_date != "") $he_approval_date = date("m/d/Y", strtotime($he_approval_date));
		$advert_date = $project_stats->advert_date; if ($advert_date == NULL) $advert_date = "";
		if ($advert_date != "") $advert_date = date("m/d/Y", strtotime($advert_date));
		$tendering_date = $project_stats->tendering_date; if ($tendering_date == NULL) $tendering_date = "";
		if ($tendering_date != "") $tendering_date = date("m/d/Y", strtotime($tendering_date));
		$evaluation_date = $project_stats->evaluation_date; if ($evaluation_date == NULL) $evaluation_date = "";
		if ($evaluation_date != "") $evaluation_date = date("m/d/Y", strtotime($evaluation_date));
		$due_process_date = $project_stats->due_process_date; if ($due_process_date == NULL) $due_process_date = "";
		if ($due_process_date != "") $due_process_date = date("m/d/Y", strtotime($due_process_date));
		$award_date = $project_stats->award_date; if ($award_date == NULL) $award_date = "";
		if ($award_date != "") $award_date = date("m/d/Y", strtotime($award_date));
		$signing_date = $project_stats->signing_date; if ($signing_date == NULL) $signing_date = "";
		if ($signing_date != "") $signing_date = date("m/d/Y", strtotime($signing_date));
		$start_date = $project_stats->start_date; if ($start_date == NULL) $start_date = "";
		if ($start_date != "") $start_date = date("m/d/Y", strtotime($start_date));
		$completion_date = $project_stats->completion_date;if ($completion_date == NULL) $completion_date = "";
		if ($completion_date != "") $completion_date = date("m/d/Y", strtotime($completion_date));


		$eoi_date_expected = $project_stats_expected->eoi_date_expected;if ($eoi_date_expected == NULL) $eoi_date_expected = "";
		if ($eoi_date_expected != "") $eoi_date_expected = date("m/d/Y", strtotime($eoi_date_expected));
		$he_approval_date_expected = $project_stats_expected->he_approval_date_expected; if ($he_approval_date_expected == NULL) $he_approval_date_expected = "";
		if ($he_approval_date_expected != "") $he_approval_date_expected = date("m/d/Y", strtotime($he_approval_date_expected));
		$advert_date_expected = $project_stats_expected->advert_date_expected; if ($advert_date_expected == NULL) $advert_date_expected = "";
		if ($advert_date_expected != "") $advert_date_expected = date("m/d/Y", strtotime($advert_date_expected));
		$tendering_date_expected = $project_stats_expected->tendering_date_expected; if ($tendering_date_expected == NULL) $tendering_date_expected = "";
		if ($tendering_date_expected != "") $tendering_date_expected = date("m/d/Y", strtotime($tendering_date_expected));
		$evaluation_date_expected = $project_stats_expected->evaluation_date_expected; if ($evaluation_date_expected == NULL) $evaluation_date_expected = "";
		if ($evaluation_date_expected != "") $evaluation_date_expected = date("m/d/Y", strtotime($evaluation_date_expected));
		$due_process_date_expected = $project_stats_expected->due_process_date_expected; if ($due_process_date_expected == NULL) $due_process_date_expected = "";
		if ($due_process_date_expected != "") $due_process_date_expected = date("m/d/Y", strtotime($due_process_date_expected));
		$award_date_expected = $project_stats_expected->award_date_expected; if ($award_date_expected == NULL) $award_date_expected = "";
		if ($award_date_expected != "") $award_date_expected = date("m/d/Y", strtotime($award_date_expected));
		$signing_date_expected = $project_stats_expected->signing_date_expected; if ($signing_date_expected == NULL) $signing_date_expected = "";
		if ($signing_date_expected != "") $signing_date_expected = date("m/d/Y", strtotime($signing_date_expected));
		$start_date_expected = $project_stats_expected->start_date_expected; if ($start_date_expected == NULL) $start_date_expected = "";
		if ($start_date_expected != "") $start_date_expected = date("m/d/Y", strtotime($start_date_expected));
		$completion_date_expected = $project_stats_expected->completion_date_expected;if ($completion_date_expected == NULL) $completion_date_expected = "";
		if ($completion_date_expected != "") $completion_date_expected = date("m/d/Y", strtotime($completion_date_expected));

		$tmp["eoi_date"] = $eoi_date;
		$tmp["he_approval_date"] = $he_approval_date;
		$tmp["advert_date"] = $advert_date;
		$tmp["tendering_date"] = $tendering_date;
		$tmp["evaluation_date"] = $evaluation_date;
		$tmp["due_process_date"] = $due_process_date;
		$tmp["award_date"] = $award_date;
		$tmp["signing_date"] = $signing_date;
		$tmp["start_date"] = $start_date;
		$tmp["timeline_date"] = $timeline[0];
		$tmp["timeline"] = $timeline[1];
		$tmp["completion_date"] = $completion_date;


		$tmp["eoi_date_expected"] = $eoi_date_expected;
		$tmp["he_approval_date_expected"] = $he_approval_date_expected;
		$tmp["advert_date_expected"] = $advert_date_expected;
		$tmp["tendering_date_expected"] = $tendering_date_expected;
		$tmp["evaluation_date_expected"] = $evaluation_date_expected;
		$tmp["due_process_date_expected"] = $due_process_date_expected;
		$tmp["award_date_expected"] = $award_date_expected;
		$tmp["signing_date_expected"] = $signing_date_expected;
		$tmp["start_date_expected"] = $start_date_expected;
		$tmp["timeline_date"] = $timeline[0];
		$tmp["timeline"] = $timeline[1];
		$tmp["completion_date_expected"] = $completion_date_expected;

		if (is_object($indicators)) {
			$tmp["stability"] = $indicators->stability;
			$tmp["technical_involvement"] = $indicators->technical_involvement;
			$tmp["legal"] = $indicators->legal;
			$tmp["socio_economic"] = $indicators->socio_economic;
			$tmp["financial"] = $indicators->financial;
			$tmp["stakeholder"] = $indicators->stakeholder;
			$tmp["completion_date_indicator"] = $indicators->completion_date;
			$tmp["geographic"] = $indicators->geographic;
			$tmp["weighted"] = $indicators->weighted;
		}
		


		$tmp["payments"] = $project->get_payments($id);
		$tmp["total_payments"] = $project->get_total_payments($id);

		$tmp["project_title"] = $project_details->name;
		$tmp["budget_provision"] = $project_details->budget_provision;
		$tmp["project_priority"] = $project_details->priority;
		$tmp["priority_code"] = $priority_code;


		$tmp["mda"] = $project_details->mda;
		$tmp["projectpartners"] = $project->get_project_partners($this->uri->server, $id);
		self::render($tmp, "view");

	}

	

	function delete() {
		$id = $this->uri->id;
		$mda = new Mda;
		$wanted->delete_wanted($id);
		$this->redirect("mda", "index");
	}


}
