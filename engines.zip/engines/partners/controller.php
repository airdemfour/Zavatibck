<?php
/**
* @package Zedek Framework
* @subpackage ZConfig zedek configuration class
* @version 4
* @author defestdude <defestdude@gmail.com> Donald Mkpanam
*/

namespace __zf__;
class CController extends ZController{
	public $app;


	function __construct() {
		parent::__construct();
		//$this->model = new user;
		$c = new ZConfig;
		$this->app = new app;
	}

	function index(){
		$partner = new Partner;
		if(isset($_POST["contact_name"])) {
			$partner->create();
		}
		$partners = $partner->get_partners($this->uri->server);
		$partner_type = $partner->get_partner_type();
		$tmp = $this->app->tmp();
		$tmp["partners"] = $partners;
		$tmp["partnertype"] = $partner_type;
		self::render($tmp, "index");
		
	}

	function view(){
		$id = $this->uri->id;
		$tmp = $this->app->tmp();
		$mda = new Mda;
		$project = new Project;
		$mda_details = $mda->get_mda($id);
		$tmp["project_count"] = $mda->get_mda_project_count($id);
		$tmp["projects"] = $project->get_projects_mda($id, $this->uri->server);
		$tmp["completed_project_count"] = $mda->get_mda_completed_project_count($id);
		$tmp["mda_name"] = $mda_details->name;
		$tmp["perm_sec"] = $mda_details->perm_sec;
		self::render($tmp, "view");

	}

	function delete() {
		$id = $this->uri->id;
		$mda = new Mda;
		$mda->delete_mda($id);
		$this->redirect("mda", "index");
	}


}
