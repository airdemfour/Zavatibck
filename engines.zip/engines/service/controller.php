<?php
/**
* @package Zedek Framework
* @subpackage ZConfig zedek configuration class
* @version 4
* @author defestdude <defestdude@gmail.com> Donald Mkpanam
*/

namespace __zf__;
class CController extends ZController{
	public $app;


	function __construct() {
		parent::__construct();
		//$this->model = new user;
		$c = new ZConfig;
		$this->app = new app;
	}

	function sos(){
		$json = file_get_contents("php://input");
		$sos = new Sos;
		$data = explode('&',$json);
		$lat = $data[0];
		$lon = $data[1];
		print_r($data);

		/*$myfile = fopen("/var/www/html/newfile.txt", "w") or die("Unable to open file!");
		$txt = "John Doe\n";
		fwrite($myfile, $lon);
		fclose($myfile);*/
		$sos->register($lat, $lon);
		
	}

	function news() {
		$news = new News;
		$output = "{\"contacts\":";
		$res = $news->get_service_news();
		$res = json_encode($res);
		$output .= $res;
		$output .= "}";
		print_r($output);
	}

	function wanted() {
		$wanted = new Wanted;
		$output = "{\"contacts\":";
		$res = $wanted->get_service_wanted();
		$res = json_encode($res);
		$output .= $res;
		$output .= "}";
		print_r($output);
	}


}
